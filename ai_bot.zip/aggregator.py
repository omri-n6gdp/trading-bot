"""
Multi-AI Stock Trading Bot — Aggregator
========================================
Paste each AI's ===PICKS_START=== ... ===PICKS_END=== block into the
AI_RESPONSES dict below, then run:  python aggregator.py

Rules:
  - Only stocks recommended by >= MIN_CONSENSUS AIs are considered
  - Ranked by average score (highest first) among recommending AIs
  - Top 5 selected; capital allocated proportionally to average score
"""

import re
from collections import defaultdict

# ─── CONFIG ──────────────────────────────────────────────────────────────────

MIN_CONSENSUS = 3          # minimum number of AIs that must pick a stock
TOP_N         = 5          # number of stocks to allocate capital across
TOTAL_CAPITAL = 10_000     # £ / $ — used only for illustrative £ allocation

# ─── PASTE AI RESPONSES HERE ─────────────────────────────────────────────────
# Replace the empty strings with each AI's full output block.
# The parser only reads between ===PICKS_START=== and ===PICKS_END===.

AI_RESPONSES = {
    "Gemini": """
===PICKS_START===
TICKER: NVDA
SCORE: 92
EXCHANGE: NASDAQ
SECTOR: Semiconductors
ENTRY: market open
STOP: 108.00
TARGET: 125.00
CATALYST: Blackwell GPU demand surge; earnings beat consensus by 18%.
EDGE: Street underestimates data-centre rack density upgrade cycle.

TICKER: AAPL
SCORE: 85
EXCHANGE: NASDAQ
SECTOR: Technology
ENTRY: market open
STOP: 170.00
TARGET: 185.00
CATALYST: India manufacturing expansion de-risks supply chain concerns.
EDGE: Institutional rebalancing into quality tech ahead of summer.

TICKER: MSFT
SCORE: 80
EXCHANGE: NASDAQ
SECTOR: Technology
ENTRY: market open
STOP: 388.00
TARGET: 415.00
CATALYST: Azure AI services revenue growing 60% YoY per latest data.
EDGE: Co-pilot seat expansion not yet priced in by buy-side models.

TICKER: META
SCORE: 75
EXCHANGE: NASDAQ
SECTOR: Communication Services
ENTRY: market open
STOP: 480.00
TARGET: 520.00
CATALYST: Ad revenue re-accelerating; AI targeting shows measurable lift.
EDGE: Llama open-source moat creates infrastructure pricing power.

TICKER: AMZN
SCORE: 70
EXCHANGE: NASDAQ
SECTOR: Consumer Discretionary
ENTRY: market open
STOP: 178.00
TARGET: 198.00
CATALYST: AWS re:Invent follow-through; bedrock enterprise contracts.
EDGE: Margin expansion via logistics automation underappreciated.
===PICKS_END===
""",

    "Claude": """
===PICKS_START===
TICKER: NVDA
SCORE: 95
EXCHANGE: NASDAQ
SECTOR: Semiconductors
ENTRY: market open
STOP: 107.50
TARGET: 128.00
CATALYST: H200 allocation sold out through Q3; supply-constrained pricing.
EDGE: Hyperscaler capex commitments lock in 18-month revenue visibility.

TICKER: META
SCORE: 88
EXCHANGE: NASDAQ
SECTOR: Communication Services
ENTRY: market open
STOP: 478.00
TARGET: 525.00
CATALYST: Threads monthly actives crossed 150M; new ad inventory unlocked.
EDGE: Reality Labs losses narrowing faster than Street expects.

TICKER: MSFT
SCORE: 82
EXCHANGE: NASDAQ
SECTOR: Technology
ENTRY: market open
STOP: 386.00
TARGET: 418.00
CATALYST: OpenAI deal restructure removes overhang; Azure guidance raised.
EDGE: Enterprise AI upsell cycle in early innings; consensus too conservative.

TICKER: GOOGL
SCORE: 76
EXCHANGE: NASDAQ
SECTOR: Communication Services
ENTRY: market open
STOP: 158.00
TARGET: 176.00
CATALYST: Gemini integration in Workspace driving seat expansion.
EDGE: Search revenue more resilient to AI disruption than feared.

TICKER: AAPL
SCORE: 72
EXCHANGE: NASDAQ
SECTOR: Technology
ENTRY: market open
STOP: 168.00
TARGET: 184.00
CATALYST: WWDC AI features announcement acting as upgrade cycle catalyst.
EDGE: Services attach rate on installed base still understated in models.
===PICKS_END===
""",

    "ChatGPT": """
===PICKS_START===
TICKER: NVDA
SCORE: 90
EXCHANGE: NASDAQ
SECTOR: Semiconductors
ENTRY: market open
STOP: 109.00
TARGET: 126.00
CATALYST: Jensen keynote catalyst; sovereign AI spending accelerating.
EDGE: CoWoS packaging capacity bottleneck breaking; sentiment to re-rate.

TICKER: AAPL
SCORE: 83
EXCHANGE: NASDAQ
SECTOR: Technology
ENTRY: market open
STOP: 169.00
TARGET: 186.00
CATALYST: iPhone 17 pre-order signals stronger than expected in China.
EDGE: Repurchase authorisation of $110B largest in company history.

TICKER: MSFT
SCORE: 79
EXCHANGE: NASDAQ
SECTOR: Technology
ENTRY: market open
STOP: 387.00
TARGET: 412.00
CATALYST: M365 Copilot seats hit 1M ahead of schedule per channel checks.
EDGE: Azure win rate vs AWS improving in regulated verticals.

TICKER: TSM
SCORE: 74
EXCHANGE: NYSE
SECTOR: Semiconductors
ENTRY: market open
STOP: 152.00
TARGET: 172.00
CATALYST: Advanced packaging ASPs rising; N2 yield ramp ahead of schedule.
EDGE: Geopolitical risk overpriced; US fab progress de-risks the discount.

TICKER: META
SCORE: 68
EXCHANGE: NASDAQ
SECTOR: Communication Services
ENTRY: market open
STOP: 475.00
TARGET: 515.00
CATALYST: Q2 ad spend RFPs stronger than seasonal norms across agencies.
EDGE: AI-driven CPM improvement not yet visible in consensus estimates.
===PICKS_END===
""",

    "Grok": """
===PICKS_START===
TICKER: NVDA
SCORE: 93
EXCHANGE: NASDAQ
SECTOR: Semiconductors
ENTRY: market open
STOP: 108.50
TARGET: 130.00
CATALYST: Blackwell shipments ramping; NIM inference platform adoption surging.
EDGE: Software attach (CUDA/NIM) creating recurring revenue nobody models.

TICKER: TSM
SCORE: 80
EXCHANGE: NYSE
SECTOR: Semiconductors
ENTRY: market open
STOP: 153.00
TARGET: 173.00
CATALYST: Apple A19 and NVIDIA B200 both on 3nm; utilisation at 96%.
EDGE: Arizona fab risk hedged by CHIPS Act; discount to fair value excessive.

TICKER: META
SCORE: 77
EXCHANGE: NASDAQ
SECTOR: Communication Services
ENTRY: market open
STOP: 477.00
TARGET: 518.00
CATALYST: Instagram Reels monetisation closing gap with TikTok.
EDGE: WhatsApp business API revenue inflecting; Street model too low.

TICKER: GOOGL
SCORE: 72
EXCHANGE: NASDAQ
SECTOR: Communication Services
ENTRY: market open
STOP: 157.00
TARGET: 175.00
CATALYST: AI Overviews retention data positive; advertiser spend returning.
EDGE: Cloud division margin inflection point reached; opex discipline held.

TICKER: AMZN
SCORE: 65
EXCHANGE: NASDAQ
SECTOR: Consumer Discretionary
ENTRY: market open
STOP: 177.00
TARGET: 196.00
CATALYST: Prime Day moved to June; incremental $2B GMV vs consensus model.
EDGE: Advertising segment $50B+ run rate not reflected in sum-of-parts.
===PICKS_END===
""",

    "DeepSeek": """
===PICKS_START===
TICKER: NVDA
SCORE: 89
EXCHANGE: NASDAQ
SECTOR: Semiconductors
ENTRY: market open
STOP: 107.00
TARGET: 124.00
CATALYST: Export licence clarity removes supply uncertainty for H20 China.
EDGE: Inference workload growth creates demand floor independent of training.

TICKER: MSFT
SCORE: 84
EXCHANGE: NASDAQ
SECTOR: Technology
ENTRY: market open
STOP: 389.00
TARGET: 416.00
CATALYST: GitHub Copilot enterprise renewals tracking above churn estimates.
EDGE: Teams AI premium tier conversion accelerating per partner data.

TICKER: GOOGL
SCORE: 78
EXCHANGE: NASDAQ
SECTOR: Communication Services
ENTRY: market open
STOP: 159.00
TARGET: 177.00
CATALYST: YouTube Shorts ad load increasing; CTV budget shift accelerating.
EDGE: TPU v5 cost advantage for own inference not factored in Street margins.

TICKER: TSM
SCORE: 73
EXCHANGE: NYSE
SECTOR: Semiconductors
ENTRY: market open
STOP: 151.00
TARGET: 170.00
CATALYST: CoWoS-L yield improving; NVDA and AAPL orders both pulling in.
EDGE: P/E at 10-year low relative to peers despite strongest order book.

TICKER: AMZN
SCORE: 67
EXCHANGE: NASDAQ
SECTOR: Consumer Discretionary
ENTRY: market open
STOP: 176.00
TARGET: 197.00
CATALYST: Bedrock foundation model usage up 3x QoQ in enterprise segment.
EDGE: Fulfillment network now near breakeven; operating leverage underappreciated.
===PICKS_END===
"""
}

# ─── PARSER ──────────────────────────────────────────────────────────────────

def parse_picks(name: str, raw: str) -> list[dict]:
    """Extract structured picks from a single AI's output block."""
    block_match = re.search(
        r"===PICKS_START===(.*?)===PICKS_END===", raw, re.DOTALL
    )
    if not block_match:
        print(f"  [WARN] No valid picks block found for {name}")
        return []

    block = block_match.group(1).strip()
    picks = []

    # Split on blank lines between picks
    entries = re.split(r"\n{2,}", block)
    for entry in entries:
        entry = entry.strip()
        if not entry:
            continue

        fields = {}
        for line in entry.splitlines():
            if ":" in line:
                key, _, val = line.partition(":")
                fields[key.strip().upper()] = val.strip()

        ticker = fields.get("TICKER", "").upper()
        score_raw = fields.get("SCORE", "")

        if not ticker:
            continue

        try:
            score = float(re.sub(r"[^\d.]", "", score_raw))
        except (ValueError, TypeError):
            print(f"  [WARN] Could not parse score for {ticker} from {name}: '{score_raw}'")
            continue

        picks.append({
            "ticker":   ticker,
            "score":    score,
            "exchange": fields.get("EXCHANGE", "—"),
            "sector":   fields.get("SECTOR",   "—"),
            "entry":    fields.get("ENTRY",     "—"),
            "stop":     fields.get("STOP",      "—"),
            "target":   fields.get("TARGET",    "—"),
            "catalyst": fields.get("CATALYST",  "—"),
            "edge":     fields.get("EDGE",      "—"),
            "source":   name,
        })

    return picks

# ─── AGGREGATION ─────────────────────────────────────────────────────────────

def aggregate(responses: dict, min_consensus: int) -> list[dict]:
    """
    For each ticker: collect all scores, filter by min_consensus,
    compute average, return sorted list.
    """
    data: dict[str, dict] = defaultdict(lambda: {"scores": [], "meta": {}})

    for ai_name, raw in responses.items():
        picks = parse_picks(ai_name, raw)
        for p in picks:
            t = p["ticker"]
            data[t]["scores"].append((ai_name, p["score"]))
            # Store metadata from the highest-scoring source
            if not data[t]["meta"] or p["score"] > data[t]["meta"].get("score", -1):
                data[t]["meta"] = p

    results = []
    for ticker, info in data.items():
        n = len(info["scores"])
        if n < min_consensus:
            continue
        avg = sum(s for _, s in info["scores"]) / n
        sources = [ai for ai, _ in info["scores"]]
        results.append({
            "ticker":   ticker,
            "avg_score": round(avg, 1),
            "count":    n,
            "sources":  sources,
            "meta":     info["meta"],
        })

    results.sort(key=lambda x: x["avg_score"], reverse=True)
    return results

# ─── ALLOCATION ──────────────────────────────────────────────────────────────

def allocate(ranked: list[dict], top_n: int, capital: float) -> list[dict]:
    """Proportional allocation based on average score."""
    top = ranked[:top_n]
    total_score = sum(s["avg_score"] for s in top)
    for s in top:
        s["alloc_pct"] = round(s["avg_score"] / total_score * 100, 1)
        s["alloc_gbp"] = round(s["avg_score"] / total_score * capital, 2)
    return top

# ─── OUTPUT ──────────────────────────────────────────────────────────────────

def print_summary(top: list[dict], capital: float):
    sep = "─" * 68

    print(f"\n{'MULTI-AI SWING TRADE — WEEKLY PICKS':^68}")
    print(sep)
    print(f"{'Stock':<8} {'Avg Score':>10} {'AIs':>4} {'Alloc %':>9} {'Alloc £':>10}  {'Exchange'}")
    print(sep)
    for s in top:
        print(
            f"{s['ticker']:<8} "
            f"{s['avg_score']:>10.1f} "
            f"{s['count']:>4} "
            f"{s['alloc_pct']:>8.1f}% "
            f"{s['alloc_gbp']:>10,.2f}  "
            f"{s['meta']['exchange']}"
        )
    print(sep)

    print(f"\n{'DETAIL':^68}")
    print(sep)
    for s in top:
        m = s["meta"]
        print(f"\n  {s['ticker']}  |  Avg {s['avg_score']}  |  {', '.join(s['sources'])}")
        print(f"  Entry: {m['entry']}   Stop: {m['stop']}   Target: {m['target']}")
        print(f"  Catalyst: {m['catalyst']}")
        print(f"  Edge:     {m['edge']}")

    print(f"\n{sep}")
    print(f"  Total capital: £{capital:,.0f}   Consensus threshold: ≥{MIN_CONSENSUS} AIs   Top {TOP_N} selected")
    print(sep)


def print_rejected(ranked: list[dict], top_n: int):
    """Show stocks that made consensus but didn't crack the top N."""
    rest = ranked[top_n:]
    if not rest:
        return
    print(f"\n  Consensus but not selected (rank {top_n + 1}+):")
    for s in rest:
        print(f"    {s['ticker']}  avg {s['avg_score']}  ({s['count']} AIs)")


# ─── MAIN ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\nParsing AI responses...")
    all_ranked = aggregate(AI_RESPONSES, MIN_CONSENSUS)

    if not all_ranked:
        print(
            f"\n  No stocks reached the ≥{MIN_CONSENSUS}-AI consensus threshold.\n"
            "  Check that each AI block is correctly pasted and delimited."
        )
    else:
        top = allocate(all_ranked, TOP_N, TOTAL_CAPITAL)
        print_summary(top, TOTAL_CAPITAL)
        print_rejected(all_ranked, TOP_N)
